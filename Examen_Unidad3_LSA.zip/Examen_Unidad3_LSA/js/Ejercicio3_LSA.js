function enviarDireccion() {
    // guardamos datos de input en variables omitiendo espacios
    let domi = domicilio.value.trim();
    let piso = numeroPiso.value.trim();
    let obser = observaciones.value.trim();
    let datos = []; // array vacio para datos introducidos

    parrafo = document.getElementById('parrafo');
    // si no existe ninguno de los datos de input (inputs vacíos)
    if (!domi && !piso && !obser) {
        parrafo.style.color = 'red';
        parrafo.innerHTML = `Error: debes introducir al menos un campo de la dirección`;
    } else {
        // añadimos a array de datos
        datos.push(domi);
        datos.push(piso)
        datos.push(obser);
        let params = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
        width=0,height=0,left=-1000,top=-1000`;
        // abrimos nueva ventana
        let newWin = window.open("Ventana3_LSA.html", "VentanaNueva", params);
        newWin.onload = function() {
            // escribimos datos en la nueva ventana dependiendo si existen en el array
            let primer_parrafo = newWin.document.getElementsByTagName('p')[0];
            if (datos[0]) {
                primer_parrafo.innerHTML = `${domi}`;
            }
            let segundo_parrafo = newWin.document.getElementsByTagName('p')[1];
            if (datos[1]) {
                segundo_parrafo.innerHTML = `${piso}`;
            }
            let tercer_parrafo = newWin.document.getElementsByTagName('p')[2];
            if (datos[2]) {
                tercer_parrafo.innerHTML = `${obser}`;
            }
        }
        // mensaje de enviado correctamente
        parrafo.style.color = 'green';
        parrafo.innerHTML = `Dirección enviada correctamente`;
    }
}