function calcularEdad() {
    // recogemos valor del input y omitimos espacios
    let fechaString = fecha.value.trim();
    // verificamos si contiene los dos guiones
    if (fechaString.includes('-') && fechaString.includes('-', 2)) {
        let primerGuion = fechaString.indexOf("-");
        let segundoGuion = fechaString.indexOf('-', primerGuion + 1);
        
        // extraemos cada substring correspondiente al dato de la fecha
        let añoString = Number(fechaString.slice(0, primerGuion));
        let mesString = Number(fechaString.slice(primerGuion + 1, segundoGuion));
        let diaString = Number(fechaString.slice(segundoGuion + 1));

        //verificamos si son numeros los substring extraidos
        if (!isNaN(añoString) && !isNaN(mesString) && !isNaN(diaString)) {
            // creamos el formato fecha a partir de los datos que tenemos
            let fecha = new Date(`${diaString}-${mesString}-${añoString}`);
            let diaActual = new Date(); // variable para la fecha actual
            if (fecha < diaActual) { // si la fecha introducida es menor que la actual ejecutamos el programa
                let diferenciaFechas = Math.abs(diaActual - fecha);
                let diferenciaAños = diferenciaFechas / (1000 * 60 * 60 * 24 * 365);

                alert(`Edad calculada: 
                    - Edad con decimales ${diferenciaAños.toFixed(2)} años
                    - Edad actual: ${Math.floor(diferenciaAños)} años
                    - Edad el próximo año: ${Math.floor(diferenciaAños + 1)} años`);

                // local storage guarda solo cuando es fecha mayor
                fechaGuardada = localStorage.getItem('fecha');
                fechaGuardadaFormato = new Date (fechaGuardada);
                if (fechaGuardadaFormato < fecha) {
                    localStorage.removeItem('fecha');
                    localStorage.setItem('fecha', fecha);
                    document.cookie= `fecha=${fecha}, max-age = -1`;
                    document.cookie= `fecha=${fecha}, max-age = 60 * 60 * 24 * 7`;
                }
            } else {
                alert('Error: La fecha introducia es posterior a la actual.');
            }


        } else {
            alert('Error: Día, mes y año deben ser valores numéricos.')
        }
        
        
    } else {
        alert('Error: La fecha debe contener guiones (-) y formato DD-MM-AAAA');
    }
}